import { useColorModeValue, IconButton, useColorMode } from "@hope-ui/solid"
//刷新按钮
import { RightIcon } from "../pages/home/toolbar/Icon"
import { RiSystemRefreshLine } from "solid-icons/ri"
import { usePath } from "~/hooks"
// 语言选择
import { SwitchLanguageWhite } from "~/components"
// 从这里到下面注释 都是搬过来的夜间模式切换代码
// 下面这两条搬过来的代码 白天黑夜图标
import { FiSun as Sun } from "solid-icons/fi"
import { FiMoon as Moon } from "solid-icons/fi"
const changeMode = () => {
  return {
    icon: useColorModeValue(
      {
        size: "$8",
        component: Moon,
        p: "$0_5",
      },
      {
        size: "$8",
        component: Sun,
        p: "$0_5",
      },
    ),
    mode: useColorMode(),
  }
}
// 到这里
// 没用过 solid-icons 不知道怎么安装单独的图标
export default () => {
  const { toggleColorMode } = changeMode().mode
  const { refresh } = usePath()
  return (
    <>
      {/* 刷新按钮移动出来 */}
      <IconButton
        class="custom-btn"
        aria-label="switch layout"
        compact
        size="lg"
        //这次支持三个不同的图标了
        icon={
          <RightIcon
            as={RiSystemRefreshLine}
            onClick={() => {
              refresh(undefined, true)
            }}
          />
        }
      />
      {/* 暗夜模式切换 */}
      <IconButton
        class="custom-btn"
        aria-label="switch layout"
        compact
        size="lg"
        //这次支持三个不同的图标了
        icon={
          <RightIcon
            // 图标已更换
            as={changeMode().icon().component}
            // tips="白天夜间模式切换"
            onClick={toggleColorMode}
          />
        }
      />
      {/* 语言选择 */}
      <IconButton
        class="custom-btn lang"
        aria-label="select language"
        compact
        size="lg"
        //这次支持三个不同的图标了
        icon={<SwitchLanguageWhite />}
      />
    </>
  )
}
