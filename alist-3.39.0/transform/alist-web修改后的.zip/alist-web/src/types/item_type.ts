export enum Type {
  String = "string",
  Select = "select",
  Bool = "bool",
  Text = "text",
  Number = "number",
}
