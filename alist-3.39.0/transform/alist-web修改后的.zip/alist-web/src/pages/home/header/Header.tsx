// 修改增加 IconButton
import {
  HStack,
  useColorModeValue,
  Image,
  Center,
  // Icon,
  // Kbd,
  CenterProps,
  IconButton,
} from "@hope-ui/solid"
// import { changeColor } from "seemly"
// 修改增加 Switch,Match
import { Show, createMemo, Switch, Match } from "solid-js"
// 修改增加 layout,setLayout
import {
  // getMainColor,
  getSetting,
  local,
  objStore,
  State,
  layout,
  setLayout,
} from "~/store"
// import { BsSearch } from "solid-icons/bs"
import { CenterLoading } from "~/components"
import { Container } from "../Container"
import { bus } from "~/utils"
import { Layout } from "./layout"
// import { isMac } from "~/utils/compatibility"
// 修改新增 三个搜索图标
import { TbListSearch } from "solid-icons/tb"
import { AiOutlineFileSearch } from "solid-icons/ai"
import customizeToolbar from "~/components/customize-toolbar"
// 没用过 solid-icons 不知道怎么安装单独的图标
function TbPhotoSearch() {
  return (
    <svg
      fill="none"
      stroke-width="2"
      xmlns="http://www.w3.org/2000/svg"
      class="icon icon-tabler icon-tabler-photo-search"
      width="1em"
      height="1em"
      viewBox="0 0 24 24"
      stroke="currentColor"
      stroke-linecap="round"
      stroke-linejoin="round"
      style="overflow: visible; color: currentcolor;"
    >
      <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
      <path d="M15 8h.01"></path>
      <path d="M11.5 21h-5.5a3 3 0 0 1 -3 -3v-12a3 3 0 0 1 3 -3h12a3 3 0 0 1 3 3v5.5"></path>
      <path d="M18 18m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0"></path>
      <path d="M20.2 20.2l1.8 1.8"></path>
      <path d="M3 16l5 -5c.928 -.893 2.072 -.893 3 0l2 2"></path>
    </svg>
  )
}
// import { CgImage } from "solid-icons/cg"
// 三个切换的图标
import { FaSolidListUl } from "solid-icons/fa"
import { BsGridFill, BsCardImage } from "solid-icons/bs"
export const Header = () => {
  const logos = getSetting("logo").split("\n")
  const logo = useColorModeValue(logos[0], logos.pop())

  const stickyProps = createMemo<CenterProps>(() => {
    switch (local["position_of_header_navbar"]) {
      case "sticky":
        return { position: "sticky", zIndex: "$sticky", top: 0 }
      default:
        return { position: undefined, zIndex: undefined, top: undefined }
    }
  })
  return (
    <Center
      {...stickyProps}
      bgColor="$background"
      class="header"
      w="$full"
      // shadow="$md"
    >
      <Container>
        <HStack
          px="calc(2% + 0.5rem)"
          py="$2"
          w="$full"
          justifyContent="space-between"
        >
          <HStack class="header-left" h="44px">
            <Image
              src={logo()!}
              h="$full"
              w="auto"
              fallback={<CenterLoading />}
            />
          </HStack>
          <HStack class="header-right" spacing="$2">
            <Show when={objStore.state === State.Folder}>
              <Show when={getSetting("search_index") !== "none"}>
                {/* 原有的搜索 */}
                {/* <HStack
                  bg="$neutral4"
                  w="$32"
                  p="$1"
                  rounded="$md"
                  justifyContent="space-between"
                  border="2px solid transparent"
                  cursor="pointer"
                  color={getMainColor()}
                  bgColor={changeColor(getMainColor(), { alpha: 0.15 })}
                  _hover={{
                    bgColor: changeColor(getMainColor(), { alpha: 0.2 }),
                  }}
                  onClick={() => {
                    bus.emit("tool", "search")
                  }}
                >
                  <Icon as={BsSearch} />
                  <HStack>
                    {isMac ? <Kbd>Cmd</Kbd> : <Kbd>Ctrl</Kbd>}
                    <Kbd>K</Kbd>
                  </HStack>
                </HStack> */}
                {/* 搜索 */}
                <IconButton
                  aria-label="Search"
                  compact
                  size="lg"
                  //这次支持三个不同的搜索图标了
                  icon={
                    <Switch>
                      <Match when={layout() === "list"}>
                        <TbListSearch />
                      </Match>
                      <Match when={layout() === "grid"}>
                        <AiOutlineFileSearch />
                      </Match>
                      <Match when={layout() === "image"}>
                        {TbPhotoSearch()}
                      </Match>
                    </Switch>
                  }
                  onClick={() => {
                    bus.emit("tool", "search")
                  }}
                />
                {/* 搜索右侧的那个变换的按钮 */}
                <IconButton
                  aria-label="switch layout"
                  compact
                  size="lg"
                  //这次支持三个不同的图标了
                  icon={
                    <Switch>
                      <Match when={layout() === "list"}>
                        <FaSolidListUl />
                      </Match>
                      <Match when={layout() === "grid"}>
                        <BsGridFill />
                      </Match>
                      <Match when={layout() === "image"}>
                        <BsCardImage />
                      </Match>
                    </Switch>
                  }
                  onClick={() => {
                    // layout 应该是获取当前布局
                    switch (layout()) {
                      case "list":
                        setLayout("grid")
                        break
                      case "grid":
                        setLayout("image")
                        break
                      case "image":
                        setLayout("list")
                        break
                    }
                  }}
                />
              </Show>
              {/* 原有的文件预览方式 */}
              {/* <Layout /> */}
              {/* 把右下角的刷新、暗夜切换、语言选择移动出来 */}
              {customizeToolbar()}
            </Show>
          </HStack>
        </HStack>
      </Container>
    </Center>
  )
}
