import {
  //  Anchor, HStack,
  VStack,
} from "@hope-ui/solid"
// import { Link } from "@solidjs/router"
// import { AnchorWithBase } from "~/components"
// import { useT } from "~/hooks"
// import { me } from "~/store"
// import { UserMethods } from "~/types"
import { useRouter } from "~/hooks"
export const Footer = () => {
  // const t = useT()
  const { to } = useRouter()
  return (
    <VStack class="footer" w="$full" py="$4">
      {/* <HStack spacing="$1">
        <Anchor href="https://github.com/alist-org/alist" external>
          {t("home.footer.powered_by")}
        </Anchor>
        <span>|</span>
        <AnchorWithBase
          as={Link}
          href={UserMethods.is_guest(me()) ? "/@login" : "/@manage"}
        >
          {t(UserMethods.is_guest(me()) ? "login.login" : "home.footer.manage")}
        </AnchorWithBase>
      </HStack> */}
      <div id="customize">
        <div class="panel">
          <div class="text-co">
            <div class="container">
              {/* 后台入口 */}
              <span class="nav-item">
                <a
                  class="custom-link"
                  style="cursor:pointer;margin-right:8px;"
                  onClick={() => {
                    to("/@manage")
                  }}
                >
                  <i class="icon-park-solid--setting" aria-hidden="true">
                    {" "}
                  </i>
                  管理
                </a>
              </span>
              |{/* 版权，请尊重作者 */}
              <span class="nav-item">
                <a
                  class="custom-link"
                  href="https://github.com/Xhofe/alist"
                  target="_blank"
                  style="margin-left:8px;"
                >
                  <i class="mingcute--link-fill" aria-hidden="true">
                    {" "}
                  </i>
                  Alist
                </a>
              </span>
            </div>
          </div>
        </div>
        <div class="access">
          <div class="text-co">
            <div class="container">
              <div>
                本"
                <span>
                  <a href="#">目录</a>
                </span>
                "访问量
                <span id="busuanzi_value_page_pv"></span>次 本站总访问量
                <span id="busuanzi_value_site_pv"></span>次 本站总访客数
                <span id="busuanzi_value_site_uv"></span>人
              </div>
            </div>
          </div>
        </div>
      </div>
    </VStack>
  )
}
