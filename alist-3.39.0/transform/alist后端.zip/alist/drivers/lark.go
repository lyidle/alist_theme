// +build linux darwin windows
// +build amd64 arm64

package drivers

import (
	_ "github.com/alist-org/alist/v3/drivers/lark"
)
