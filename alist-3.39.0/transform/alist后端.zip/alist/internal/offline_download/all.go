package offline_download

import (
	_ "github.com/alist-org/alist/v3/internal/offline_download/115"
	_ "github.com/alist-org/alist/v3/internal/offline_download/aria2"
	_ "github.com/alist-org/alist/v3/internal/offline_download/http"
	_ "github.com/alist-org/alist/v3/internal/offline_download/pikpak"
	_ "github.com/alist-org/alist/v3/internal/offline_download/qbit"
	_ "github.com/alist-org/alist/v3/internal/offline_download/transmission"
)
